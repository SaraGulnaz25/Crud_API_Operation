from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK, HTTP_400_BAD_REQUEST,HTTP_404_NOT_FOUND,HTTP_204_NO_CONTENT
from employee_details.models import emp
from django.conf import settings

session = settings.DB_SESSION

class EmployeeView(APIView):
   
   def get(self, request):
      data = fetch_data()
      result = logic_on_data(data)
      return Response(result,status=HTTP_200_OK)

   def post(self, request):
      
       data = request.data
       result = insert_data(data)
       if result:
          return Response("Data saved Sucessfully",status=HTTP_200_OK)
       else:
          return Response("error", status=HTTP_400_BAD_REQUEST)

   def patch(self, request):
      
    employee_id = request.data.get('id')
    if not employee_id:
        return Response("Employee ID is required.", status=HTTP_400_BAD_REQUEST)
    data = request.data
    if update_employee(employee_id, data):
        return Response("Employee details updated: " +  str(data), status=HTTP_200_OK)
    else:
        return Response("Employee not found." , status=HTTP_404_NOT_FOUND)

   def put(self, request):
      data = request.data
      emp_id = data.get('id')
      if not emp_id:
         return Response("ID is required for PUT request", status=HTTP_400_BAD_REQUEST)
      existing_employee = session.query(emp).filter_by(id=emp_id).first()
      if existing_employee:
         existing_employee.name = data.get('name', existing_employee.name)
         existing_employee.lname = data.get('lname', existing_employee.lname)
         existing_employee.address = data.get('address', existing_employee.address)
         session.commit()
         return Response("Employee details updated successfully" +  str(data), status=HTTP_200_OK)
      else:
         return Response("Employee not found", status=HTTP_400_BAD_REQUEST)

   def delete(self, request):
         data = request.data
         emp_id = data.get('id')
         if not emp_id:
            return Response("Id is required", status=HTTP_200_OK)
         existing_emp = session.query(emp).filter_by(id = emp_id).first()
         if existing_emp:
            session.delete(existing_emp)
            session.commit()
            return Response("Employee Deleted Sucessfully", status=HTTP_204_NO_CONTENT)
         else:
            return Response("Employee not found", status=HTTP_400_BAD_REQUEST)

def logic_on_data(data_list):
   # prepare data
   # compuatation on data fetch to be done here. data  should be fetched from fetch_data()
  
   final_list = []
   if data_list:
      for data in data_list:
         single_record = {}
         single_record['id'] = data[0]
         single_record['name'] = data[1]
         single_record['lname'] = data[2]
         single_record['address'] = data[3]
         final_list.append(single_record)
      return final_list

def fetch_data():
   # SQLALchemy query part only. models in separate files
   result_set = session.query(emp.id, emp.name, emp.lname, emp.address).all()
   # list of tuples [(1, "adad", 'wdfwe', "test add"), (), ()]
   return result_set

def insert_data(data):

   emp_details = emp(
      id = data['id'],
      name= data['name'],
      lname= data['lname'],
      address= data['address'],
   )
   session.add(emp_details)
   session.commit()
   return True

def update_employee(employee_id, data):
    employee = session.query(emp).filter_by(id=employee_id).first()
    if employee:
        for key, value in data.items():
            setattr(employee, key, value)
        session.commit()
        return True
    else:
        return False