from sqlalchemy import Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base


Base = declarative_base()

class emp(Base):
    __tablename__ = 'emp'
    id = Column(Integer, primary_key=True)
    name = Column(String(30))
    lname = Column(String(30))
    address = Column(String(100))

    