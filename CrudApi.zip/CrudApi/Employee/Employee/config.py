from sqlalchemy import create_engine, Column, Integer, String, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

engine = create_engine(url = 'mysql://<root>:<root>@<localhost>/<mydb>', echo=True)
Base = declarative_base()


Base.metadata.create_all(engine)

Session = sessionmaker(bind=engine)
session = Session()